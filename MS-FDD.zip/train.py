import warnings
warnings.filterwarnings('ignore')
from ultralytics import YOLO

if __name__ == '__main__':
    model = YOLO('/root/ultralytics-yolov8-8.1.0-old/ultralytics-yolov8-8.1.0/yolov8-cfg/yolov8-att-bifpn-head.yaml')
    # model.load('yolov8n.pt') # loading pretrain weights
    model.train(data='/root/huaweidataset/class.yaml',
                cache=False,
                imgsz=640,
                epochs=150,
                batch=32,
                close_mosaic=10,
                workers=8,
                device='0',
                optimizer='SGD', # using SGD
                patience=150,
                # resume='runs/train/exp/weights/last.pt', # last.pt path
                # amp=False, # close amp
                # fraction=0.2,
                project='runs/train',
                name='yolov8-att-bifpn-head2025',
                # hyp
                # lr0=0.0115,
                # lrf=0.01,
                # momentum=0.96379,
                )
